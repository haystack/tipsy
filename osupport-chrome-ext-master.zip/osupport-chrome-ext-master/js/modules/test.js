define({
	color: "blue"
});