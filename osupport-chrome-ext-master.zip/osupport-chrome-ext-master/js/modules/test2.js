define([
	"jquery",
	"test",
	//"handlebars",
	],
	function($, test) {
		console.log($);
		//console.log(handlebars);
		
		return {
			color: "red",
			baseColor: test.color,
		};

	// End of Module define function closure.
	}
);