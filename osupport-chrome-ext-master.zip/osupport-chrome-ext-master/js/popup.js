(function() {
	var title = chrome.browserAction.getTitle({}, function(result) {
	//console.log(title);
		//alert(result);
	});
	console.log("hello");

	console.log(title)


	



})();